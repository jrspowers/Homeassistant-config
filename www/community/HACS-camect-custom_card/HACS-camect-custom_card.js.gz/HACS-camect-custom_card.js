import "https://home.camect.com/js/ha_card.js";
